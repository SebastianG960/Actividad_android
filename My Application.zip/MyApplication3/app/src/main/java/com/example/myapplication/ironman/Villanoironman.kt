package com.example.myapplication.ironman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class Villanoironman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.villanoironman)
    }

    fun Regresarironv(@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)}

        fun Descripcionironv (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, ironman ::class.java).apply {  }
        startActivity(intent)
    }
    fun Casaironv (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, casaironman::class.java).apply {  }
        startActivity(intent)
    }

}