package com.example.myapplication.batman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class batman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.batman)
    }
    fun Regresarbatman (@Suppress("UNUSED_PARAMETER") view: View){
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun villanobatman  (@Suppress("UNUSED_PARAMETER") view: View){
        val intent= Intent (this, villanobatman::class.java).apply {  }
        startActivity(intent)
    }
    fun casabatman ( @Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, casabatman::class.java).apply {  }
        startActivity(intent)
    }
}