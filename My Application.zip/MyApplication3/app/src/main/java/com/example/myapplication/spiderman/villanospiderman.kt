package com.example.myapplication.spiderman

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class villanospiderman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.villanospiderman)
    }

    fun regresarspidermav(@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)}

        fun descripcionspidermanv (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, spiderman ::class.java).apply {  }
        startActivity(intent)
    }
    fun casaspidermanv (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, casaspiderman::class.java).apply {  }
        startActivity(intent)
    }

}