package com.example.myapplication.batman

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class casabatman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.casabatman)
    }
    fun Regresarbatman (@Suppress("UNUSED_PARAMETER") view: View){
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun Descripcionbatman (@Suppress("UNUSED_PARAMETER") view: View){
        val intent= Intent (this, batman ::class.java).apply {  }
        startActivity(intent)
    }
    fun villanobatman (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, villanobatman::class.java).apply {  }
        startActivity(intent)
    }
}