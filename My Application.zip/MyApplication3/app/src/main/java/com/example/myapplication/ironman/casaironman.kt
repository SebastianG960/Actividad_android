package com.example.myapplication.ironman

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class casaironman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.casaironman)
    }
    fun Regresarironc (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun Descripcionironc (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, ironman ::class.java).apply {  }
        startActivity(intent)
    }
    fun villanoironc (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, Villanoironman::class.java).apply {  }
        startActivity(intent)
    }
}