package com.example.myapplication.batman

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class villanobatman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.villanobatman)
    }

    fun Regresarbatmanv (@Suppress("UNUSED_PARAMETER")view: View) {
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)}

    fun Descripcionbatmanv (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, batman ::class.java).apply {  }
        startActivity(intent)
    }
    fun Casabatmanv (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, casabatman::class.java).apply {  }
        startActivity(intent)
    }

}