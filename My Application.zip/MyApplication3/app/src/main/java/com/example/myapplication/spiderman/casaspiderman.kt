package com.example.myapplication.spiderman

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class casaspiderman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.casaspiderman)
    }
    fun regresarspidermanc (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun descripcionspidermanc (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, spiderman ::class.java).apply {  }
        startActivity(intent)
    }
    fun villanospidermanc (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, villanospiderman::class.java).apply {  }
        startActivity(intent)
    }
}