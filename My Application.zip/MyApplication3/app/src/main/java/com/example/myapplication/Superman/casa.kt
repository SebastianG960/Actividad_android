package com.example.myapplication.Superman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class casa : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.casasuperman)
    }
    fun Regresar (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun Descripcion (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, superman ::class.java).apply {  }
        startActivity(intent)
    }
    fun villano (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, Villano::class.java).apply {  }
        startActivity(intent)
    }
}