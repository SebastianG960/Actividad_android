package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.myapplication.Superman.superman
import com.example.myapplication.batman.batman
import com.example.myapplication.ironman.ironman
import com.example.myapplication.spiderman.spiderman

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun superman(@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this,superman::class.java).apply {  }
        startActivity(intent)
}

    fun batman(@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this,batman::class.java).apply {  }
        startActivity(intent)
    }

    fun ironman(@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this,ironman::class.java).apply {  }
        startActivity(intent)
    }
    fun spiderman(@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this,spiderman::class.java).apply {  }
        startActivity(intent)
    }
}