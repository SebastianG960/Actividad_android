package com.example.myapplication.ironman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class ironman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ironman)
    }
    fun Regresariron (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, MainActivity::class.java).apply {  }
        startActivity(intent)
    }
    fun Villanoiron (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, Villanoironman::class.java).apply {  }
        startActivity(intent)
    }
    fun Lugariron (@Suppress("UNUSED_PARAMETER")view: View){
        val intent= Intent (this, casaironman::class.java).apply {  }
        startActivity(intent)
    }
}